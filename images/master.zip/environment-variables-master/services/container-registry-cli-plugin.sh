#!/bin/sh

export GITHUB_REPO=container-registry-cli-plugin
export SERVICE_OUTPUT_DIR=$GITHUB_REPO
export SERVICE_WRITERS="$sue"
export CHARGEtoID=${projectCode}ABD228
export SERVICE_SLACK_CHANNEL=\#doctopus-registry
