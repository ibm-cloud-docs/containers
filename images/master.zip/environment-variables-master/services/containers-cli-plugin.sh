#!/bin/sh

export GITHUB_REPO=containers-cli-plugin
export SERVICE_OUTPUT_DIR=$GITHUB_REPO
export SERVICE_WRITERS="$art $nadine $rachael"
#export CHARGEtoID=${projectCode}ABD068
#export SOURCE_ORG_REPO=alchemy-containers/documentation
export SERVICE_SLACK_CHANNEL=\#doctopus-containers

#export CLI_SOURCE_FILE=cs_cli_reference.md
#export CLI_REPO=containers-cli-plugin
#export CLI_REPO_FILE=kubernetes-service-cli.md
