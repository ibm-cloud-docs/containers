#!/bin/sh

export GITHUB_REPO=cloud-functions-cli-plugin
export SERVICE_OUTPUT_DIR=$GITHUB_REPO
export SERVICE_WRITERS="$derek"
export CHARGEtoID=${projectCode}ABD182
export SERVICE_SLACK_CHANNEL=\#docs-openwhisk
