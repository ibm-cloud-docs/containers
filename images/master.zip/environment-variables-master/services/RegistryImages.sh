#!/bin/sh

export GITHUB_REPO=RegistryImages
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$sue"
export CHARGEtoID=${projectCode}ABD173
export SERVICE_SLACK_CHANNEL=\#doctopus-registry
