#!/bin/sh

export GITHUB_REPO=terraform
export SERVICE_OUTPUT_DIR=$GITHUB_REPO
export SERVICE_WRITERS="$nadine $derek"
export CHARGEtoID=
