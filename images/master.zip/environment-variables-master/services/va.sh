#!/bin/sh

export GITHUB_REPO=va
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$sue"
export CHARGEtoID=${projectCode}ABD172
export SOURCE_ORG_REPO=alchemy-va/documentation
export SERVICE_SLACK_CHANNEL=\#doctopus-registry
