#!/bin/sh

export GITHUB_REPO=docker-for-bluemix
export SERVICE_OUTPUT_DIR=$GITHUB_REPO
export SERVICE_WRITERS="$kristin"
#export CHARGEtoID=${projectCode}ABD068
export SOURCE_ORG_REPO=alchemy-writers/docker-for-bluemix

export CLI_SOURCE_FILE=cs_cli_reference.md
export CLI_REPO=docker-for-bluemix-cli-plugin
export CLI_REPO_FILE=index.md
