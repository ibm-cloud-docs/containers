#!/bin/sh

export GITHUB_REPO=cloud-activity-tracker
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$marisa"
export CHARGEtoID=${projectCode}ABD080
export SERVICE_SLACK_CHANNEL=\#doctopus-armada-lm
