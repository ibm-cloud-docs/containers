#!/bin/sh

export GITHUB_REPO=EventStreams
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$karen"
export CHARGEtoID=${projectCode}ABD074
