export GITHUB_REPO=cloud-object-storage
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$nicholas"
# Not translated yet
# SET CHARGEtoID=
