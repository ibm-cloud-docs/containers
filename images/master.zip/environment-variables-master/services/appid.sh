#!/bin/sh

export GITHUB_REPO=appid
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$shawna"
export CHARGEtoID=${projectCode}ABD155
export SOURCE_ORG_REPO=alchemy-writers/appid
export SERVICE_SLACK_CHANNEL=\#appid-docs
