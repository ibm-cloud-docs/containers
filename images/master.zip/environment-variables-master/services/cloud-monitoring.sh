#!/bin/sh

export GITHUB_REPO=cloud-monitoring
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$marisa"
export CHARGEtoID=${projectCode}ABD160
export SERVICE_SLACK_CHANNEL=\#doctopus-armada-lm
