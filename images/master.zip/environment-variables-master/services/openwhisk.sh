#!/bin/sh

export GITHUB_REPO=openwhisk
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$derek"
export CHARGEtoID=${projectCode}ABD182
export SERVICE_SLACK_CHANNEL=\#docs-openwhisk
