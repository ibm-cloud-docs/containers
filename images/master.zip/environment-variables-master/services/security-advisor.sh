#!/bin/sh

export GITHUB_REPO=security-advisor
export SERVICE_OUTPUT_DIR=services/$GITHUB_REPO
export SERVICE_WRITERS="$shawna"
export CHARGEtoID=${projectCode}ABD221
